#!/usr/bin/env python
# coding: utf-8

# In[105]:


import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel


# In[117]:


pd.set_option('display.max_colwidth', None)
books_tag= pd.read_csv(r'H:\cosc757\cosc897\books\books_tags.csv')


# In[123]:


books_tag['mix']=(pd.Series(books_tag[['authors', 'tag_name']]
                        .fillna('')
                        .values.tolist()
                       ).str.join(' '))


# In[129]:


tf_mix=TfidfVectorizer(analyzer='word', ngram_range=(1,2), min_df=0, stop_words='english')
tfidf_matrix_mix=tf_mix.fit_transform(books_tag['mix'])
cosine_sim_mix= linear_kernel(tfidf_matrix_mix, tfidf_matrix_mix)

titles=books_tag['title']
indices=pd.Series(books_tag.index, index=books_tag['title'])


def recommendations(title):
    idx=indices[title]
    sim_scores=list(enumerate(cosine_sim_mix[idx]))
    sim_scores=sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores=sim_scores[1:11]
    book_indices= [i[0] for i in sim_scores]
    return titles.iloc[book_indices]


def find_tag(tag):
    print(books_tag.title[books_tag['tag_name'].str.contains(tag,na =False, case=False)])


def find_name(name):
    print(books_tag.title[books_tag['title'].str.contains(name,na =False, case=False)])


# In[128]:


recommendations("Common Sense")


# In[120]:

find_name("sense")


# In[130]:


find_tag("funny")

