from flask import Flask, render_template, request
import books
import sqlite3 as sql
from urllib.request import urlopen

app = Flask(__name__)


@app.route("/")
@app.route("/home")
def home():
    con = sql.connect("books.db")
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from books order by random() limit 1;")

    rows = cur.fetchall()
    return render_template("home.html", rows=rows, )


@app.route("/contact")
def contact():
    return render_template('contact.html')


@app.route("/random", methods=['GET','POST'])
def random():

    con = sql.connect("books.db")
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from books order by random() limit 10;")

    rows = cur.fetchall()
    return render_template("/random.html",rows=rows,)


@app.route("/popular", methods=['GET','POST'])
def popular():

    con = sql.connect("books.db")
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from books order by ratings_count desc limit 50;")

    rows = cur.fetchall()
    return render_template("/popular.html",rows=rows,)


@app.route("/top_rated", methods=['GET','POST'])
def top_rated():

    con = sql.connect("books.db")
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from books order by average_rating desc limit 50;")

    rows = cur.fetchall()
    return render_template("/top_rated.html",rows=rows,)


@app.route('/book_detail/<i>', methods=['GET','POST'])
def book_detail(i):

    con = sql.connect("books.db")
    con.row_factory = sql.Row
    cur = con.cursor()
    rows = cur.execute("select * from books where title is '%s' " % i)
    result = books.recommendations(i)
    return render_template("book_detail.html", rows=rows, result=result.values)


@app.route("/search_result", methods = ['POST'])
def search_result():
    drop = request.form.get("drop")
    title = request.form['title']
    title="%"+title+"%"
    con = sql.connect("books.db")
    con.row_factory = sql.Row

    cur = con.cursor()
    if drop == 'book':
        rows = cur.execute("select * from books where title like '%s' " % title)
    elif drop == 'author':
        rows = cur.execute("select * from books where authors like '%s' " % title)
    else:
        rows = cur.execute("select * from books where tag_name like '%s' " % title)

    row = cur.fetchone()
    if row is None:
        print("Sorry there are no results.")
    return render_template("search_result.html", rows=rows)


if __name__ == '__main__':
    app.run(debug=True)